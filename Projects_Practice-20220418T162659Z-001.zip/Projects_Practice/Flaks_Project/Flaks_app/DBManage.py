from models import WIP, wipRoutings, wipCompletion,tableCreate
import csv
class DBManage():

	def __init__(self):

		self.db_path = r'database\db.db'
		self.WIP_path = r"\\ad.numatic.co.uk\group\Operations\Production Assembly\Metal Shop\Supply_sheet_all_departments\Supply All Departments.csv"
		self.weekly_supply_db_path = r'database\weekly_supply.db'

	def updateWIPTable(self,db):
		#delete rows from the table
		WIP.query.delete()

		#load new table from csv file
		with open(self.WIP_path,"r") as csvfile:
		    file = csv.reader(csvfile)
		    for row in file:
		    	if (row[6] == 'METAL SHOP') and (row[6] != 'PAINT SHOP'):
		        	#cur.execute('INSERT INTO WIP VALUES (?,?,?,?,?,?,?,?)',(row[0],row[1],row[2],row[3],row[4],row[6],row[7],row[11]))
		        	insert = WIP(WEEK_NUMBER = row[0] ,
		        		WIP_ENTITY_NAME = row[1],
		        		PART_NUMBER  = row[2],
		        		PART_DESCRIPTION = row[3],
		        		QUANTITY = row[4],
		        		DEPARTMENT_CLASS = row[6],
		        		DEPARTMENT  = row[7],
		        		OPERATION_DESCRIPRION  =row[11])
		        	db.session.add(insert)
		    db.session.commit()

	def refreshWIPTable(self):
		wip_data = wipRoutings.query.filter_by(STATUS = 'In Progress').all()
	
		return wip_data

	def insertToWIPcompletion(self,db,datetime):
		#job_details,job_qty,job_routing

		insert = wipCompletion(WEEK_NUMBER = job_details[3], WIP_ENTITY_NAME = job_details[0]
			, PART_NUMBER = job_details[1],ROUTING = job_routing, QUANTITY = job_qty,DATE_COMPLETE = datetime.datetime.utcnow())

		db.session.add(insert)
		db.session.commmit()
		# insert = wipCompletion(WEEK_NUMBER = 2, WIP_ENTITY_NAME = 5 , 
		# PART_NUMBER = 6,ROUTING = 'SEW', QUANTITY = 9,DATE_COMPLETE = datetime.datetime.utcnow())

		# db.session.add(insert)
		# db.session.commit()

	def loadWeekSupply(self, file, file_name, week_no):

		table = tableCreate(file_name)

		

		for row in file.iterrows():

			if (row[1][0] == int(week_no)) and (row[1][7] != 'WELD DEPT') and (row[1][7] !='PAINT CELL'):
		        #cur.execute(f'INSERT INTO {file_name} VALUES (?,?,?,?,?,?)',(row[1][0],row[1][1],row[1][2],row[1][3],row[1][11],row[1][4]))
				insert_to_table = table(WEEK_NUMBER = row[1][0], WIP_ENTITY_NAME = row[1][1],
		  				PART_NUMBER =  row[1][2], PART_DESCRIPTION = row[1][3],ROUTING = row[1][11],QUANTITY = row[1][4])
				db.session.add(insert_to_table)
		db.session.commit()


  