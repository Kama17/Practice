
if __name__ == '__main__':

#	from DBManage import DBManage
	from app import app

	#from app import db

	app.run(debug = True)