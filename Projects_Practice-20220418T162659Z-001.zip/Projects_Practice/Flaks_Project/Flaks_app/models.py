from app import db
#db = SQLAlchemy(app)

class WIP(db.Model):
	__tablename__ = "WIP"

	id = db.Column(db.Integer, primary_key = True, unique = True, nullable = False)
	WEEK_NUMBER = db.Column(db.Integer, nullable = False)
	WIP_ENTITY_NAME = db.Column(db.Integer, nullable = False)
	PART_NUMBER = db.Column(db.Integer, nullable = False)
	PART_DESCRIPTION = db.Column(db.String, nullable = False)
	QUANTITY = db.Column(db.Integer,nullable = True)
	DEPARTMENT_CLASS = db.Column(db.String, nullable = False)
	DEPARTMENT = db.Column(db.String, nullable = False)
	OPERATION_DESCRIPRION = db.Column(db.String, nullable = False)




	def __repr__(self):
		return f"""id: {self.id}\n
					Week: {self.WEEK_NUMBER}\n
					Job number: {self.WIP_ENTITY_NAME}\n
					Part number: {self.PART_NUMBER}\n
					Part description: {self.PART_DESCRIPTION}\n
					Department Class: {self.DEPARTMENT_CLASS}\n
					Department: {self.DEPARTMENT}\n
					Operation: {self.OPERATION_DESCRIPRION}\n
					"""

class wipCompletion(db.Model):
	__tablename__ = "WIP_COMPLETION"

	id = db.Column(db.Integer, primary_key = True, unique = True, nullable = False)
	WEEK_NUMBER = db.Column(db.Integer, nullable = False)
	WIP_ENTITY_NAME = db.Column(db.Integer, nullable = False)
	PART_NUMBER = db.Column(db.Integer, nullable = False)
	ROUTING = db.Column(db.String, nullable = False)
	QUANTITY = db.Column(db.Integer, nullable = False)
	DATE_COMPLETE = db.Column(db.DateTime, nullable = False)


	def __repr__(self):
		return f"""id: {self.id}\n
					Week: {self.WEEK_NUMBER}\n
					Job number: {self.WIP_ENTITY_NAME}\n
					Part number: {self.PART_NUMBER}\n
					Routing: {self.ROUTING}\n
					Quantity: {self.QUANTITY}\n
					Date: {self.DATE_COMPLETE}\n
					Operation: {self.OPERATION_DESCRIPRION}\n
					"""

class wipRoutings(db.Model):
	__tablename__ = "WIP_ROUTINGS"

	id = db.Column(db.Integer, primary_key = True, unique = True, nullable = False)
	WEEK_NUMBER = db.Column(db.Integer, nullable = False)
	WIP_ENTITY_NAME = db.Column(db.Integer, nullable = False)
	PART_NUMBER = db.Column(db.Integer, nullable = False)
	PART_DESCRIPTION = db.Column(db.String, nullable = False)
	ROUTING = db.Column(db.String, nullable = False)
	QUANTITY = db.Column(db.Integer, nullable = False)
	COMPLETE = db.Column(db.Integer, nullable = True)
	STATUS = db.Column(db.String, nullable = True)


	# def __repr__(self):
	# 	return f"""id: {self.id}\n
	# 				Job number: {self.WIP_ENTITY_NAME}\n
	# 				Part number: {self.PART_NUMBER}\n
	# 				Part description: {self.PART_DESCRIPTION}\n
	# 				Routing: {self.ROUTING}\n
	# 				Quantity: {self.QUANTITY}\n
	# 				Complete: {self.COMPLETE}\n
	# 				Status: {self.STATUS}\n
	# 				"""

	
def tableCreate(name):

    tabledict={'id':db.Column(db.Integer, primary_key = True),
               'WEEK_NUMBER':db.Column(db.Integer),
               'WIP_ENTITY_NAME':db.Column(db.Integer),
               'PART_NUMBER':db.Column(db.Integer),
               'PART_DESCRIPTION':db.Column(db.String),
               'QUANTITY':db.Column(db.Integer)}
   
    db.metadata.clear()
    table_exists = db.engine.table_names()
    #Define table
    new_table = type(name, (db.Model,), tabledict)
   	
   	# If exist in database
    if name not in table_exists:
    	
    	new_table.__table__.create(db.session.bind)

    	a = new_table(WEEK_NUMBER = 10)
    	db.session.add(new_table)
    	db.session.commit()
    	return new_table
    # Drop and create if exists
    elif name in table_exists:
    	new_table.__table__.drop(db.session.bind)
    	new_table.__table__.create(db.session.bind)
    	return new_table


