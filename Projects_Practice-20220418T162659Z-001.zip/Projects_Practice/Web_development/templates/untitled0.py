        <a href="{{ url_for('edit', task_id=task.id) }}" class="btn btn-primary">Edit</a>
        <a href="{{ url_for('delete', task_id=task.id) }}" class="btn btn-danger">Delete</a>

